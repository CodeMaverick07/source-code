import { SignUp } from "@/components/auth/sign-up";
 
export default function Page() {
  return <SignUp />;
};
