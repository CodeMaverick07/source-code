const Page = () => {
  return ( 
    <div>
      Onboarding
    </div>
  );
};
 
export default Page;
